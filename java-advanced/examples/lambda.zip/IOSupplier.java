package lambda;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
@FunctionalInterface
interface IOSupplier<T> {
    T get() throws IOException;

    static <T> T unchecked(final IOSupplier<T> supplier) {
        try {
            return supplier.get();
        } catch (final IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    static void main(final String... args) {
        for (final String arg : args) {
            final List<String> lines = IOSupplier.unchecked(() -> Files.readAllLines(Paths.get(arg)));
            System.out.println("--- Contents of " + arg);
            lines.forEach(System.out::println);
            System.out.println(lines);
        }
    }
}
