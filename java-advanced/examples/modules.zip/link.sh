#!/bin/bash -eu
bash build.sh

rm -rf __testApp

jlink \
    --module-path "__modules:$JAVA_HOME/jmods" \
    --add-modules info.kgeorgiy.java.testModule \
    --output __testApp
