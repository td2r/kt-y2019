import info.kgeorgiy.java.helloModule.service.impl.HelloServiceEn;
import info.kgeorgiy.java.helloModule.service.impl.HelloServiceFr;

module info.kgeorgiy.java.helloModule {
    requires transitive java.rmi;
    requires jdk.httpserver;

    exports info.kgeorgiy.java.helloModule.exported;

    opens info.kgeorgiy.java.helloModule.opened;

    exports info.kgeorgiy.java.helloModule.exportedAndOpened;
    opens   info.kgeorgiy.java.helloModule.exportedAndOpened;

    exports info.kgeorgiy.java.helloModule.test to info.kgeorgiy.java.testModule;
    opens   info.kgeorgiy.java.helloModule.test to info.kgeorgiy.java.testModule;

    exports  info.kgeorgiy.java.helloModule.service;
    provides info.kgeorgiy.java.helloModule.service.HelloService with
            HelloServiceEn,
            HelloServiceFr;
}