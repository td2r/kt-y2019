package info.kgeorgiy.java.helloModule;

class PackagePrivateHello {
    public static void main(final String... args) {
        System.out.println("Hello from " + PackagePrivateHello.class.getSimpleName());
    }
}
