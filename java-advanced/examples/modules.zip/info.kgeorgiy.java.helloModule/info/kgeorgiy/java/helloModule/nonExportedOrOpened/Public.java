package info.kgeorgiy.java.helloModule.nonExportedOrOpened;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public class Public {
    static public int publicField;
    static protected int protectedField;
    static int packagePrivateField;
    static private int privateField;
}
