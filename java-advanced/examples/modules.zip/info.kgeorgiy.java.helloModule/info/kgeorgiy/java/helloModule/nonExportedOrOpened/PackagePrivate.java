package info.kgeorgiy.java.helloModule.nonExportedOrOpened;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
class PackagePrivate {
    static public int publicField;
    static protected int protectedField;
    static int packagePrivateField;
    static private int privateField;
}
