package info.kgeorgiy.java.helloModule.service.impl;

import info.kgeorgiy.java.helloModule.service.HelloService;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public class HelloServiceFr {
    public static HelloService provider() {
        return to -> System.out.format("        Bonjour, %s%n", to);
    }
}
