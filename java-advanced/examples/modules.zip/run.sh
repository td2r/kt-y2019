#!/bin/bash -eu

java -p __modules --module info.kgeorgiy.java.helloModule/info.kgeorgiy.java.helloModule.PublicHello
java -p __modules --module info.kgeorgiy.java.testModule/info.kgeorgiy.java.testModule.Main
