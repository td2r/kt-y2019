package javadoc;

public class JavadocExample1 {
    /** Calculates factorial. */
    public double factorial(int x) {
        return (x <= 1) ? 1 : x * factorial(x - 1);
    }
}
