package net;

import java.net.*;
import java.io.*;

public class HelloServer {
    private final static int SERVER_PORT = 12345;

    public static void main(String[] args) throws IOException {
        ServerSocket ssocket = new ServerSocket(SERVER_PORT);
        while (true) {
            Socket socket = ssocket.accept();
            try {
                DataInput dis = new DataInputStream(socket.getInputStream());
                String user = dis.readUTF();

                System.out.println(user);

                DataOutput dos = new DataOutputStream(socket.getOutputStream());
                dos.writeUTF("Hello, " + user + "!");
            } finally {
                socket.close();
            }
        }
    }
}
