package net;

import java.net.*;
import java.io.*;

public class FTP {
    public static void main(String[] args) throws Exception {
        if (args.length < 4) {
            System.out.println("Usage: FTP <host> <file> <user> <password>");
            return;
        }
        String host = args[0];
        String file = args[1];
        String user = args[2];
        String password = args[3];

        URL url = new URL("ftp://" + user + ":" + password + "@" + host + "" + file);
        System.out.println("Getting " + url);

        URLConnection connection = url.openConnection();
        connection.connect();
        InputStream is = connection.getInputStream();
        int c;
        while ((c = is.read()) != -1) {
            System.out.print((char) c);
        }
    }
}