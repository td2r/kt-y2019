#!/bin/bash
java -cp .. rmi.BankWebServer
